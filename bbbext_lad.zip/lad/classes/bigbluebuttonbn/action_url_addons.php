<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Contains class to add learning analytics callback URL to action URL.
 *
 * @package    bbbext_lad
 * @copyright  2026, think modular
 * @author     think modular (stefan.weber@think-modular.com)
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
namespace bbbext_lad\bigbluebuttonbn;

/**
 * A single action class to mutate the action URL.
 *
 * @package    bbbext_lad
 * @copyright  2026, think modular
 * @author     think modular (stefan.weber@think-modular.com)
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class action_url_addons extends \mod_bigbluebuttonbn\local\extension\action_url_addons {
    /**
     * Add learning analytics callback to the action URL.
     *
     * @param string $action
     * @param array $data
     * @param array $metadata
     * @param int|null $instanceid
     * @return array associative array with the additional data and metadata (indexed by 'data' and
     * 'metadata' keys)
     */
    public function execute(
        string $action = '',
        array $data = [],
        array $metadata = [],
        ?int $instanceid = null
    ): array {
        if ($instanceid && $action == 'create') {

            // Check if enabled.
            global $DB;

            $record = $DB->get_record('bbbext_lad', ['bigbluebuttonbnid' => $instanceid]);
            if ($record && $record->enabled == 1) {
                $url = new \moodle_url('/local/bbb_lad/callback.php', [
                    'instanceid' => $instanceid,
                    'secret' => $record->secret,
                ]);
                $url = $url->out(false);
                $metadata['analytics-callback-url'] = $url;
            }
        }

        return [
            'data' => $data,
            'metadata' => $metadata,
        ];
    }
}
